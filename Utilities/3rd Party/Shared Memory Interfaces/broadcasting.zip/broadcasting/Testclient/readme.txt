To test the broadcasting functionality, please start ACC v1.0 once, and edit your Documents\config\broadcasting.json to 

{
    "updListenerPort": 9000,
    "connectionPassword": "asd",
    "commandPassword": ""
}

Then you can simply launch a SP or MP session, and click "connecte" in the first tab. The default values should allow you to immediately connect.