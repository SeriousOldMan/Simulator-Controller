Assetto Corsa Internal memory reader
Created to add functinality to Crew Chief that is otherwise inaccessible.
Classes are as minimal as can be to prevent the less moraly gifted from exploiting the Sim.